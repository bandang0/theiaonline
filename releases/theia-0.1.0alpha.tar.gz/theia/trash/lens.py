'''Defines the Lens class for theia.'''

# Provides:
#   class Lens

from units import *
from component import OpticalComponent

class Lens(OpticalComponent):
    '''

    Lens class.


    *=== Attributes ===*


    *=== Methods ===*

    '''
